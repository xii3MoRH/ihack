Discord Hack Code
This Code Will Create A lot of Channels (Voice & Text)
and will give you adminstrator in the server target 
and will spam into the channel
and any member join in the server will give him a adminstrator role
all of that in just on 1 command !
AND THIS CODE WILL BAN ALL MEMBERS !
Packages : Discord.js to install npm i discord.js
ENJOY
EVIL
BY : ME !
OrochiX .
